@if ($chat->message != null)
    <div class="chat-coversation right {{ ($chat->as_proof)?'proof':'' }}">
        <div class="media">
            <div class="media-body">
                <div class="influencer-chat radius-10">{{ $chat->message }}</div>
                <span class="time">{{ Carbon\Carbon::parse($chat->created_at)->diffForHumans() }}</span>
            </div>
            <span class="avatar avatar-xs flex-shrink-0">
                @if ($chat->sender->photo != null)
                    <img src="{{ custom_asset($chat->sender->photo) }}">
                @else
                    <img src="{{ my_asset('assets/frontend/default/img/avatar-place.png') }}">
                @endif
            </span>
        </div>
    </div>
@endif
@if ($chat->attachment != null)
    <div class="chat-coversation right {{ ($chat->as_proof)?'proof':'' }}">
        <div class="media">
            <div class="media-body">
                <div class="file-preview box sm">
                    @foreach (json_decode($chat->attachment) as $key => $attachment_id)
                        @php
                            $attachment = \App\Upload::find($attachment_id);
                        @endphp
                        @if ($attachment != null)
                            @if ($attachment->type == 'image')
                                <div class="mb-2 file-preview-item" title="{{ $attachment->file_name }}">
                                    <a href="{{ route('download_attachment', $attachment->id) }}" target="_blank" class="d-block">
                                        <div class="thumb">
                                            <img src="{{ my_asset($attachment->file_name) }}" class="img-fit">
                                        </div>
                                    </a>
                                    <div class="body">
                                        <h6 class="d-flex">
                                            <span class="text-truncate title">{{ $attachment->file_original_name }}</span>
                                            <span class="ext">.{{ $attachment->extension }}</span>
                                        </h6>
                                        <p>{{formatBytes($attachment->file_size)}}</p>
                                    </div>
                                </div>
                            @else
                                <div class="mb-2 file-preview-item" title="{{ $attachment->file_name }}">
                                    <a href="{{ route('download_attachment', $attachment->id) }}" target="_blank" class="d-block">
                                        <div class="thumb">
                                            <i class="la la-file-text"></i>
                                        </div>
                                    </a>
                                    <div class="body">
                                        <h6 class="d-flex">
                                            <span class="text-truncate title">{{ $attachment->file_original_name }}</span>
                                            <span class="ext">.{{ $attachment->extension }}</span>
                                        </h6>
                                        <p>{{formatBytes($attachment->file_size)}}</p>
                                    </div>
                                </div>
                            @endif
                        @else
                            <div class="alert alert-secondary" role="alert">
                                {{ translate('No attachment') }}
                            </div>
                        @endif
                    @endforeach
                </div>
                <span class="time">{{ Carbon\Carbon::parse($chat->created_at)->diffForHumans() }}</span>
            </div>
            <span class="avatar avatar-xs flex-shrink-0">
                <img @if ($chat->sender->photo != null) src="{{ custom_asset(($chat->sender->photo))}}" @endif>
            </span>
        </div>
    </div>
@endif

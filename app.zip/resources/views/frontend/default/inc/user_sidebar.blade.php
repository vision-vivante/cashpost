<div class="col-sm-3 d-none d-sm-block"  style="height:100vh;">
    <span class="overlay-gradient"></span>
    <img src="{{ asset('/public/uploads/all/img-side.png') }}" alt="..." class="overlay">
    <div class="content position-relative">
    	<a href="{{ route('home') }}" class="d-inline-block">
       	 	<img src="{{ asset('/public/uploads/all/icon-cash.png') }}" alt="" class="img-fluid mx-auto p-3">
    	</a>
        <h3 class="text-white pt-7 px-4 text-24">"World's most affordable influencer marketing platform."</h3>
    </div>
</div>
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SubscribeForm extends Model
{
    protected $table = 'subscribe_form';
    protected $fillable = ['email'];
    //
}
